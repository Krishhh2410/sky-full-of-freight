# Sky Full of Freight ✈️
### Air Cargo Load Analysis & Airline Clustering — SFO (2000–2023)

---

## Background

I came across this dataset while looking into how airlines manage cargo operations alongside passenger services — something that doesn't get nearly as much attention as route pricing or seat utilization. What caught my attention was the sheer scale: belly cargo on commercial passenger flights is a significant revenue stream, yet capacity decisions are often made with limited visibility into patterns across carriers.

This project is my attempt to bring some structure to that question. I wanted to understand which airlines are dominant cargo players, how the freight mix (dedicated freighters vs. passenger belly) has shifted over two decades, and whether there are distinct operational profiles among carriers that might explain how they make capacity decisions.

The short answer: yes, and the clusters tell a surprisingly clean story.

---

## Dataset

**Air Traffic Cargo Statistics** — San Francisco International Airport (SFO), sourced from the [City & County of San Francisco Open Data Portal](https://data.sfgov.org/).

- **Period**: July 1999 – September 2023
- **Airlines**: 130 unique operators
- **Records**: ~53,000 rows across airline × month × cargo type × aircraft type × direction

Key fields: `Operating Airline`, `GEO Region`, `GEO Summary`, `Activity Type Code` (Enplaned/Deplaned), `Cargo Type Code` (Cargo/Mail/Express), `Cargo Aircraft Type` (Freighter/Passenger/Combi), `Cargo Weight LBS`, `Cargo Metric TONS`.

---

## Project Structure

```
sky-freight/
├── data/
│   ├── Air_Traffic_Cargo_Statistics.csv    ← raw dataset
│   ├── cargo_cleaned.csv                   ← cleaned, date-parsed
│   ├── cargo_master.csv                    ← enriched with cluster labels
│   ├── monthly_cargo_powerbi.csv           ← aggregated for Power BI
│   └── airline_clusters.csv               ← airline-level features + cluster
├── notebooks/
│   └── analysis.py                         ← full pipeline (EDA + clustering)
├── outputs/
│   ├── 01_cargo_trend.png
│   ├── 02_top_airlines.png
│   ├── 03_cargo_type_geo.png
│   ├── 04_seasonal_heatmap.png
│   ├── 05_freighter_vs_belly.png
│   ├── 06_elbow_silhouette.png
│   ├── 07_cluster_scatter.png
│   └── 08_cluster_profiles.png
├── powerbi_guide/
│   ├── POWERBI_GUIDE.md                    ← step-by-step dashboard setup
│   └── powerbi_theme.json                  ← custom dark theme
└── README.md
```

---

## What I Did

### Phase 1 — Data Cleaning
Parsed the `Activity Period` field (stored as integer YYYYMM) into proper year/month columns, converted date strings to datetime, handled ~578 missing IATA codes, and filtered to post-2000 records for statistical consistency. Exported a clean base CSV.

### Phase 2 — Exploratory Analysis

A few things stood out immediately:

- **International cargo dominates** at 57.7% of total tonnage — this is SFO, so trans-Pacific routes account for a disproportionate share.
- **The 2020 COVID shock is visible but brief.** Cargo actually recovered faster than passenger traffic because belly capacity was replaced by expanded freighter operations. The data shows this clearly in the freighter vs. belly split chart.
- **Seasonal patterns are consistent** — October through December consistently run higher cargo volumes, aligning with pre-holiday e-commerce and retail inventory cycles.
- **The top 3 carriers** (United Airlines predecessor entities, FedEx, and UPS) account for a substantial portion of total tonnage despite 127 airlines in the dataset.

### Phase 3 — Clustering

I built airline-level features for clustering: average monthly cargo tonnage, freighter aircraft share, international route share, and an enplaned-to-total balance ratio (how directionally balanced each airline's cargo flow is).

K-Means with K=4, validated via WCSS elbow curve and silhouette score. Four profiles emerged:

| Cluster | Description |
|---------|-------------|
| **Dominant Carriers** | High total volume, mixed domestic/international, long operational history at SFO |
| **High-Volume Regional** | Strong tonnage, primarily domestic or single-region focus |
| **Specialized Freighters** | >90% freighter aircraft share, often full international routing, dedicated cargo operators |
| **Niche / Seasonal Operators** | Low average volume, limited record counts — charter carriers, seasonal routes, defunct airlines |

### Phase 4 — Power BI Dashboard

Three-page dashboard built against the exported CSVs:
- **Page 1**: Executive overview — KPI cards, volume trend, top airlines, cargo type split
- **Page 2**: Regional & route deep dive — monthly trends by aircraft type, GEO region breakdown, enplaned vs. deplaned by region
- **Page 3**: Cluster intelligence — scatter plot with cluster annotations, feature comparison bars, business interpretation panel

---

## Key Findings

1. **57.7% of cargo is international**, with Europe and Asia as the dominant destination regions — both significantly outpacing domestic US tonnage.
2. **Freighter aircraft carry a disproportionate share of express and high-value cargo**, while passenger belly cargo skews toward general cargo and mail.
3. **COVID caused the sharpest single-year dip in the 24-year dataset (2020)**, but total tonnage recovered to near pre-pandemic levels by 2022.
4. **The K-Means clustering cleanly separates** dedicated cargo operators (FedEx, UPS) from legacy carriers using belly capacity — the freighter share feature does most of the work.
5. **47 airlines fall into the Niche/Seasonal cluster** — these operators average very low monthly tonnage and would be first candidates for capacity reallocation discussions.

---

## Business Implications

- Airlines in the **Niche/Seasonal cluster** with low balance ratios (heavily enplaned or deplaned) may benefit from cargo partnership agreements to improve directional utilization.
- The **COVID period (2020–2021)** shows that when passenger belly capacity collapses, dedicated freighter capacity does not fully compensate — a 23% tonnage gap remained at the trough.
- **October–December seasonality** is consistent enough across years to warrant pre-committed capacity planning for carriers in the Dominant and High-Volume clusters.

---

## Stack

- **Python**: pandas, NumPy, scikit-learn (KMeans), Matplotlib, Seaborn
- **Visualization**: Power BI Desktop (dark theme, custom DAX measures)
- **Clustering**: K-Means (K=4, StandardScaler, WCSS + silhouette validation)

---

## Running the Analysis

```bash
# Install dependencies
pip install pandas numpy scikit-learn matplotlib seaborn openpyxl

# Run from notebooks/ directory
cd notebooks
python analysis.py
```

Outputs are written to `../outputs/` and `../data/`.

---

## Dashboard

> Power BI dashboard published at: **[add link after publishing]**

Screenshots:

| Executive Overview | Regional Deep Dive | Cluster Intelligence |
|---|---|---|
| *(add screenshot)* | *(add screenshot)* | *(add screenshot)* |
